#!/bin/bash
# 部署后初始化脚本 - 简化版

# 设置日志文件
LOG_FILE="startup_log.txt"
exec > >(tee -a $LOG_FILE) 2>&1

echo "=============== 开始部署初始化 [$(date)] ==============="

# 初始化环境变量
export PYTHONUNBUFFERED=1
export FLASK_ENV=production
export FLASK_APP=app.py

# 显示环境详情以便调试
echo "Python版本: $(python --version)"
echo "当前目录: $(pwd)"
echo "目录内容: $(ls -la)"

# 测试Python环境
echo "测试Python环境..."
python -c "import sys; print(sys.version); print(sys.executable)"

# 测试Flask应用启动
echo "测试Flask应用启动..."
python -c "import test_app; print('Flask应用导入成功')" || echo "Flask应用导入失败"

# 确保gunicorn可用
if ! command -v gunicorn &> /dev/null; then
    echo "警告: gunicorn未找到! 正在安装..."
    pip install gunicorn
fi

echo "=============== 初始化完成 [$(date)] ==============="
echo "启动脚本已完成。应用程序现在应该可用。"
