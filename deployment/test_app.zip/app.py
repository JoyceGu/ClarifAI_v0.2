#!/usr/bin/env python
import logging
import sys
from test_app import app, application

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

logger.info("Azure App Service启动: 从simple_app.py导入应用")

# 这里不需要添加任何代码，只需导入应用实例
# app和application变量已经在test_app.py中定义 