#!/bin/bash
# 部署后初始化脚本 - 优化版本

# 设置日志文件
LOG_FILE="startup_log.txt"
exec > >(tee -a $LOG_FILE) 2>&1

echo "=============== 开始部署初始化 [$(date)] ==============="

# 初始化环境
export FLASK_APP=run.py
export FLASK_ENV=production

# 设置Azure App Service环境变量，避免重复进行缓慢的Python构建过程
export SCM_DO_BUILD_DURING_DEPLOYMENT=true

echo "正在初始化数据库..."
flask db upgrade

# 创建初始测试用户（如果不存在）
python << 'PYTHON_SCRIPT'
from app import create_app, db
from app.models.user import User, UserRole
from werkzeug.security import generate_password_hash

app = create_app('production')
with app.app_context():
    # 检查是否已有用户
    if User.query.count() == 0:
        # 创建PM用户
        pm_user = User(
            email='pm@test.com',
            username='Product Manager',
            role=UserRole.PM
        )
        pm_user.password_hash = generate_password_hash('password123')
        
        # 创建研究员用户
        researcher_user = User(
            email='researcher@test.com',
            username='Researcher',
            role=UserRole.RESEARCHER
        )
        researcher_user.password_hash = generate_password_hash('password123')
        
        db.session.add(pm_user)
        db.session.add(researcher_user)
        db.session.commit()
        print("已创建初始测试用户")
    else:
        print("已存在用户，跳过初始用户创建")
PYTHON_SCRIPT

# 使应用正确加载Azure配置
echo "正在优化Azure服务连接配置..."
if [ -n "$WEBSITE_SITE_NAME" ]; then  # 检查是否在Azure环境中
    echo "在Azure环境中运行，启用应用缓存..."
    touch .skip-lock  # 避免每次都重新构建
    
    # 创建web.debug.config
    if [ ! -f "web.debug.config" ]; then
        cp web.config web.debug.config
    fi
fi

echo "=============== 初始化完成 [$(date)] ==============="
