#!/bin/bash
# 部署后初始化脚本

# 设置日志文件
LOG_FILE="startup_log.txt"
exec > >(tee -a $LOG_FILE) 2>&1

echo "=============== 开始部署初始化 [$(date)] ==============="

# 初始化环境变量
export PYTHONUNBUFFERED=1
export FLASK_APP=run.py
export FLASK_ENV=production

# 显示环境详情
echo "Python版本: $(python --version)"
echo "当前目录: $(pwd)"
echo "目录内容: $(ls -la)"

# 确认依赖安装
echo "检查Python包..."
pip list

# 验证数据库配置
echo "数据库URL: $DATABASE_URL"
if [ -z "$DATABASE_URL" ]; then
    echo "警告: DATABASE_URL未设置，可能会导致问题!"
fi

# 初始化数据库
echo "初始化数据库..."
flask db upgrade || {
    echo "警告: 数据库迁移失败，继续执行..."
}

echo "=============== 初始化完成 [$(date)] ==============="
echo "启动脚本已完成。应用程序现在应该可用。"
