#!/usr/bin/env python
import sys
import logging
import os

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger()

try:
    logger.info("正在初始化ClarifAI应用...")
    
    # 设置环境变量
    os.environ['FLASK_APP'] = 'run.py'
    if 'FLASK_ENV' not in os.environ:
        os.environ['FLASK_ENV'] = 'production'
    
    logger.info(f"使用环境: {os.environ.get('FLASK_ENV')}")
    
    # 导入应用
    from app import create_app
    
    # 创建应用实例
    app_config = os.environ.get('FLASK_ENV', 'production')
    logger.info(f"使用配置: {app_config}")
    application = create_app(app_config)
    
    logger.info("ClarifAI应用初始化成功")
except Exception as e:
    logger.error(f"应用初始化失败: {str(e)}", exc_info=True)
    raise

# 应用实例的名称必须为'application'，这是WSGI标准 