#!/usr/bin/env python
from flask import Flask, jsonify
import logging
import sys
import os

# 配置日志记录
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

# 创建应用
app = Flask(__name__)

@app.route('/')
def home():
    logger.info("主页被访问")
    return jsonify({
        "status": "success",
        "message": "ClarifAI测试应用程序正在运行",
        "environment": os.environ.get('FLASK_ENV', 'development')
    })

@app.route('/health')
def health():
    return jsonify({"status": "healthy"})

@app.route('/env')
def env():
    env_vars = {}
    for key, value in os.environ.items():
        if not key.startswith(('AZURE_', 'SECRET_', 'PASSWORD')):
            env_vars[key] = value
    return jsonify(env_vars)

# 这是必需的用于azure应用服务
application = app

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    logger.info(f"应用程序启动在端口: {port}")
    app.run(host='0.0.0.0', port=port) 